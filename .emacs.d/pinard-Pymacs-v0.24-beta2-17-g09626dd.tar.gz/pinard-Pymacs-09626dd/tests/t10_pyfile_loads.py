# -*- coding: utf-8 -*-

# Checking if pymacs.py loads.

def test_1():
    import setup
